<?php
// Mulai sesi dan koneksi ke database
session_start();
include('../config/config.php');

// Variabel untuk menampung hasil pencarian
$searchResults = [];

// Mengecek apakah form pencarian disubmit
if (isset($_POST['search'])) {
    // Menangkap kata kunci pencarian dari form
    $keyword = mysqli_real_escape_string($conn, $_POST['keyword']);
    
    // Query untuk mencari destinasi berdasarkan nama atau deskripsi
    $sql = "SELECT * FROM destinations WHERE name LIKE '%$keyword%' OR description LIKE '%$keyword%'";
    $result = mysqli_query($conn, $sql);
    
    // Jika ada hasil pencarian
    if (mysqli_num_rows($result) > 0) {
        // Menyimpan hasil pencarian dalam array
        while ($row = mysqli_fetch_assoc($result)) {
            $searchResults[] = $row;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pencarian Destinasi | Wisata Nusantara</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

    <?php include('../includes/header.php'); ?>

    <section class="search-section">
        <div class="container">
            <h2 class="text-center mb-4">Cari Destinasi Wisata</h2>
            
            <!-- Form Pencarian -->
            <form action="search.php" method="POST" class="mb-5">
                <div class="input-group">
                    <input type="text" name="keyword" class="form-control" placeholder="Masukkan kata kunci..." required>
                    <button class="btn btn-primary" type="submit" name="search">Cari</button>
                </div>
            </form>
            
            <!-- Hasil Pencarian -->
            <?php if (isset($_POST['search'])): ?>
                <?php if (count($searchResults) > 0): ?>
                    <h3>Hasil Pencarian</h3>
                    <div class="row">
                        <?php foreach ($searchResults as $destination): ?>
                            <div class="col-md-4 mb-4">
                                <div class="card">
                                    <img src="../assets/img/borobudur.jpg<?php echo $destination['image']; ?>" class="card-img-top" alt="<?php echo $destination['name']; ?>">
                                    <div class="card-body">
                                        <h5 class="card-title"><?php echo $destination['name']; ?></h5>
                                        <p class="card-text"><?php echo substr($destination['description'], 0, 100); ?>...</p>
                                        <a href="destination.php?id=<?php echo $destination['id']; ?>" class="btn btn-primary">Lihat Detail</a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p class="alert alert-warning">Tidak ada hasil yang ditemukan untuk kata kunci "<?php echo htmlspecialchars($keyword); ?>"</p>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </section>

    <?php include('../includes/footer.php'); ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
