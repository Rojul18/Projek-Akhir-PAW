<?php
// Mulai sesi dan panggil koneksi database
session_start();
include '../config/config.php';
include '../includes/header.php';

// Ambil ID destinasi dari URL
if (isset($_GET['destination_id']) && is_numeric($_GET['destination_id'])) {
    $destination_id = $_GET['destination_id'];
    $sql = "SELECT * FROM destinations WHERE id = $destination_id";
    $result = $conn->query($sql);
    $destination = $result->fetch_assoc();

    if (!$destination) {
        echo "<p class='text-center mt-5'>Destinasi tidak ditemukan.</p>";
        include '../includes/footer.php';
        exit;
    }
} else {
    echo "<p class='text-center mt-5'>ID destinasi tidak valid.</p>";
    include '../includes/footer.php';
    exit;
}

// Proses pengiriman formulir
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $travel_date = $_POST['travel_date'];
    $num_people = $_POST['num_people'];

    $stmt = $conn->prepare("INSERT INTO bookings (destination_id, name, email, phone, travel_date, num_people) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("issssi", $destination_id, $name, $email, $phone, $travel_date, $num_people);

    if ($stmt->execute()) {
        echo "<p class='text-center mt-5 text-success'>Pemesanan berhasil disimpan!</p>";
    } else {
        echo "<p class='text-center mt-5 text-danger'>Terjadi kesalahan saat menyimpan pemesanan. Silakan coba lagi.</p>";
    }
    $stmt->close();
}
?>

<main>
    <div class="container mt-5">
        <h1 class="text-center">Pesan Perjalanan</h1>
        <p class="text-center">Isi formulir di bawah ini untuk memesan perjalanan ke <strong><?php echo htmlspecialchars($destination['name']); ?></strong>.</p>

        <form method="POST" class="mt-4">
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="name" class="form-label">Nama Lengkap</label>
                        <input type="text" class="form-control" id="name" name="name" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="phone" class="form-label">Nomor Telepon</label>
                        <input type="text" class="form-control" id="phone" name="phone" required>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="travel_date" class="form-label">Tanggal Perjalanan</label>
                        <input type="date" class="form-control" id="travel_date" name="travel_date" required>
                    </div>
                    <div class="mb-3">
                        <label for="num_people" class="form-label">Jumlah Orang</label>
                        <input type="number" class="form-control" id="num_people" name="num_people" min="1" required>
                    </div>
                </div>
            </div>
            <button type="submit" class="btn btn-primary w-100">Pesan Sekarang</button>
        </form>
    </div>
</main>

<?php
include '../includes/footer.php';
$conn->close();
?>
