<?php
// Mulai sesi dan panggil koneksi database
session_start();
include '../config/config.php';
include '../includes/header.php';

// Ambil ID destinasi dari URL
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = $_GET['id'];
    // Query untuk mendapatkan detail destinasi
    $sql = "SELECT * FROM destinations WHERE id = $id";
    $result = $conn->query($sql);
    $destination = $result->fetch_assoc();

    if (!$destination) {
        echo "<p class='text-center mt-5'>Destinasi tidak ditemukan.</p>";
        include '../includes/footer.php';
        exit;
    }
} else {
    echo "<p class='text-center mt-5'>ID destinasi tidak valid.</p>";
    include '../includes/footer.php';
    exit;
}
?>

<main>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-6">
                <img src="../<?php echo htmlspecialchars($destination['image_url']); ?>" class="img-fluid rounded" alt="<?php echo htmlspecialchars($destination['name']); ?>">
            </div>
            <div class="col-md-6">
                <h1><?php echo htmlspecialchars($destination['name']); ?></h1>
                <p class="text-muted">Kategori: <?php echo htmlspecialchars($destination['category']); ?></p>
                <p><?php echo htmlspecialchars($destination['description']); ?></p>
                <a href="booking.php?destination_id=<?php echo $destination['id']; ?>" class="btn btn-primary mt-3">Pesan Sekarang</a>
            </div>
        </div>

        <!-- Opsional: Tampilkan lokasi pada peta Google Maps -->
        <?php if (!empty($destination['latitude']) && !empty($destination['longitude'])): ?>
        <div class="mt-5">
            <h3>Lokasi</h3>
            <iframe 
                width="100%" 
                height="300" 
                style="border:0" 
                loading="lazy" 
                allowfullscreen 
                src="https://www.google.com/maps/embed/v1/view?key=YOUR_GOOGLE_MAPS_API_KEY&center=<?php echo $destination['latitude']; ?>,<?php echo $destination['longitude']; ?>&zoom=14">
            </iframe>
        </div>
        <?php endif; ?>
    </div>
</main>

<?php
include '../includes/footer.php';
$conn->close();
?>
