<?php
// Mulai sesi dan panggil koneksi database
session_start();
include '../config/config.php';

// Cek apakah pengguna adalah admin

include '../includes/header.php';

// Ambil daftar pemesanan dari database
$sql = "SELECT b.id, b.name, b.email, b.phone, b.travel_date, b.num_people, d.name AS destination, b.created_at, b.Status
        FROM bookings b
        JOIN destinations d ON b.destination_id = d.id
        ORDER BY b.created_at DESC";
$result = $conn->query($sql);
?>

<main>
    <div class="container mt-5">
        <h1 class="text-center">Dashboard Admin</h1>
        <p class="text-center">Daftar pemesanan yang telah dilakukan oleh pengguna.</p>

        <table class="table table-striped mt-4">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>Destinasi</th>
                    <th>Tanggal Perjalanan</th>
                    <th>Jumlah Orang</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "
                        <tr>
                            <td>{$row['id']}</td>
                            <td>{$row['name']}</td>
                            <td>{$row['email']}</td>
                            <td>{$row['destination']}</td>
                            <td>{$row['travel_date']}</td>
                            <td>{$row['num_people']}</td>
                            <td>{$row['Status']}</td>
                            <td>
                                <a href='edit_booking.php?id={$row['id']}' class='btn btn-warning btn-sm'>Edit</a>
                                <a href='delete_booking.php?id={$row['id']}' class='btn btn-danger btn-sm' onclick='return confirm(\"Yakin ingin menghapus?\")'>Delete</a>
                            </td>
                        </tr>
                        ";
                    }
                } else {
                    echo "<tr><td colspan='8' class='text-center'>Tidak ada pemesanan yang tersedia.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</main>

<?php
include '../includes/footer.php';
$conn->close();
?>
