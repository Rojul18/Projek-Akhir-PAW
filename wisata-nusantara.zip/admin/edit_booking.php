<?php
// Mulai sesi dan panggil koneksi database
session_start();
include '../config/config.php';

// Cek apakah pengguna adalah admin
if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header('Location: login.php'); // Jika bukan admin, arahkan ke login
    exit;
}

if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = $_GET['id'];

    // Ambil data pemesanan dari database
    $sql = "SELECT * FROM bookings WHERE id = $id";
    $result = $conn->query($sql);
    $booking = $result->fetch_assoc();

    if (!$booking) {
        echo "<p class='text-center mt-5'>Pemesan tidak ditemukan.</p>";
        include '../includes/footer.php';
        exit;
    }
} else {
    echo "<p class='text-center mt-5'>ID pemesanan tidak valid.</p>";
    include '../includes/footer.php';
    exit;
}

// Proses pembaruan status pemesanan
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $status = $_POST['status'];

    $stmt = $conn->prepare("UPDATE bookings SET status = ? WHERE id = ?");
    $stmt->bind_param("si", $status, $id);

    if ($stmt->execute()) {
        echo "<p class='text-center mt-5 text-success'>Status pemesanan berhasil diperbarui.</p>";
    } else {
        echo "<p class='text-center mt-5 text-danger'>Terjadi kesalahan saat memperbarui status.</p>";
    }
    $stmt->close();
}
?>

<main>
    <div class="container mt-5">
        <h1 class="text-center">Edit Pemesanan</h1>
        <p class="text-center">Ubah status pemesanan untuk <strong><?php echo htmlspecialchars($booking['name']); ?></strong></p>

        <form method="POST">
            <div class="mb-3">
                <label for="status" class="form-label">Status Pemesanan</label>
                <select class="form-select" id="status" name="status" required>
                    <option value="Diproses" <?php echo $booking['status'] === 'Diproses' ? 'selected' : ''; ?>>Diproses</option>
                    <option value="Selesai" <?php echo $booking['status'] === 'Selesai' ? 'selected' : ''; ?>>Selesai</option>
                    <option value="Dibatalkan" <?php echo $booking['status'] === 'Dibatalkan' ? 'selected' : ''; ?>>Dibatalkan</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary w-100">Simpan Perubahan</button>
        </form>
    </div>
</main>

<?php
include '../includes/footer.php';
$conn->close();
?>
